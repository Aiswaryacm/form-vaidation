let email= document.getElementById("email");
 let email_error= document.getElementById("email_error");
 let phonenumber_error= document.getElementById("phonenumber_error");
 let error= document.getElementById("password_error");
 let pwd= document.getElementById("pwd");
 let phonenumber = document.getElementById("phonenumber");


 email.onkeyup = function emailvalidate() {
    let regexp =/^([A-Za-z0-9\.-]+)@([A-Za-z0-9\-]+).([a-z]{2,3}(.[a-z]{2,3}?))$/


    if(regexp.test(email.value)){
        email_error.innerHTML="VALID";
        email_error.style.color="green";
        }
        else {
         
            email_error.innerHTML="INVALID";
            email_error.style.color="red";
        
        }
    }
    // phonenumber..................................
    phonenumber.onkeyup = function numbervalidate() {
    
        let regexp =/^([0-9]{10})$/ 
        let format2 =/^([0-9]{3})\-([0-9]{3})\-([0-9]{4})$/
        let format3 =/^([0-9]{3})\.([0-9]{3})\.([0-9]{4})$/
        let format4 =/^([0-9]{3})\s([0-9]{3})\s([0-9]{4})$/
        
    
        if(regexp.test(phonenumber.value)|| format2.test(phonenumber.value)|| format3.test(phonenumber.value)||format4.test(phonenumber.value)){
           phonenumber_error.innerHTML="VALID";
           phonenumber_error.style.color="green";
                 
             }
               else {
                    
                     phonenumber_error.innerHTML="INVALID";
                     phonenumber_error.style.color="red";
                 
                   }
   }
//    passwrd.....................
// When the user clicks on the password field, show the message box
pwd.onkeyup = function pwdvalidate() {
    var matchedCase = new Array();
    matchedCase.push("[$@$!%*#?&]"); // Special Charector
    matchedCase.push("[A-Z]");      // Uppercase Alpabates
    matchedCase.push("[0-9]");      // Numbers
    matchedCase.push("[a-z]");     // Lowercase Alphabates

    // Check the conditions
    var ctr = 0;
    for (var i = 0; i < matchedCase.length; i++) {
        if (new RegExp(matchedCase[i]).test(pwd.value)) {
            ctr++;
        }
    }
    // Display it
    var color = "";
    var strength = "";
    var flag=false;
    switch (ctr) {
        case 0:
        case 1:
        case 2:
            strength = "poor";
            color = "red";
            break;
        case 3:
        case 4:
            strength = "Medium";
            color = "orange";
            flag=true;
            break;
    }
    if(flag && pwd.value.length>7)
    {
        strength = "Strong";
                        color = "green";
    }

    document.getElementById("password_error").innerHTML = strength;
    document.getElementById("password_error").style.color = color;
}
function validateform(){
  

}